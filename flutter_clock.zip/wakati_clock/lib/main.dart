import 'package:flutter/material.dart';
import 'package:wakati_clock/app.dart';
import 'package:wakati_clock/blocs/state_widget.dart';

void main() => runApp(new StateWidget(child: WakatiApp()));
