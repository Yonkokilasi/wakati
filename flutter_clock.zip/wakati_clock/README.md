# wakati_clock

A flutter clock face UI for the Flutter [Clock Challenge](https://flutter.dev/clock#)

## Getting Started

This project is built in flutter.

Example
<img src='screenshot.png' width='350'>
